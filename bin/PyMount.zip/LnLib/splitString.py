#!/usr/bin/python2.7
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Version ......: 18-06-2020 11.48.17


# #################################################################
# #  link:  http://stackoverflow.com/questions/4998629/python-split-string-with-multiple-delimiters
# #  splitString with multiple delimiters
# #  delimiters:    LIST/TUPLE of delimiters
# #  Example:
# #     l='/dev/sda1: LABEL="TOSHIBA EXT" UUID="843671A53671993E" TYPE="ntfs" PARTUUID="7fcb449d-01"'
# #     stringSplitRE(l, (':', '=', '"'))
# #     out: ['/dev/sda1', ' LABEL', '', 'TOSHIBA EXT', ' UUID', '', '843671A53671993E', ' TYPE', '', 'ntfs', ' PARTUUID', '', '7fcb449d-01', '']
# #################################################################
def stringSplitRE(string, delimiters, maxsplit=0, remove_empty=True, strip_elements=True):
    import re
    regexPattern = '|'.join(map(re.escape, delimiters))
    re.compile(regexPattern) #per velocizzare ma solo se il pattern è sempre lo stesso
    result=re.split(regexPattern, string, maxsplit)
    if remove_empty:
        result = [x for x in result if x.strip()] #  remove empty elements
    if strip_elements:
        result = [x.strip() for x in result if x.strip()] #  strip elements
    return result

