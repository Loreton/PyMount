#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Version ......: 06-09-2020 16.57.47
#
# Scope:  aggiunge dei metodi alle classi di sistema
#
# ######################################################################################
import sys
import shutil

from pathlib import Path
# from time import strftime
import time



##############################################################################
# - classe utile da mettere in qualche modulo.
##############################################################################
class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=info=debug1=debug2=debug3=set_level=dummy

logger=nullLogger() # default

################################################
################################################
def setLoggerLN(lnLogger):
    global logger
    logger=lnLogger

################################################
################################################
def LnPathCopy(source, target):
    #assert Path(source).is_file()
    '''
    alternative of Path.copy
    copyfile only if size or mtime ad differents
    params:
        target : target
        vSize  : verify fileSize
        vMTime : verify mTime
    '''

    source = Path(source)
    target = Path(target)
    logger.info('working on files: {} - {}'.format(source._str, target._str))
    diffSize, diffTime = False, False
    src = source.stat()
    tgt = src # default nel caso target non esista.
    if target.exists():
        tgt = target.stat()
        diffSize = (src.st_size != tgt.st_size)
        diffTime = (src.st_mtime > tgt.st_mtime)

    logger.info('diffTime value: {0} <--> {1}'.format(src.st_mtime, tgt.st_mtime))
    logger.info('diffSize value: {0} <--> {1}'.format(src.st_size, tgt.st_size))

    if diffTime:
        logger.info('copying file...')
        shutil.copy(source._str, target._str)
    elif diffSize:
        logger.warning('same DATETIME but different SIZE... NOT copied')
    else:
        logger.info('DATETIME and SIZE are equals. copy skipped...')


################################################
#  by Loreto:  16-04-2020 07.29.01
################################################
def LnPathMoveFile(source, target_file, create_parent=False, replace=False):
    assert source.is_file()
    source = Path(source)
    target = Path(target_file)
    logger.info(f'moving file:', [f'from {source}', f'to   {target}'])

    # create tree if required and not exists
    if create_parent:
        target.parent.mkdir(parents=True, exist_ok=True)

    moved = False
    reason = '___'
    if target.exists():
        if target.is_file():
            logger.info('   target file already exists.')
            if replace:
                logger.info('   Moving and Replacing...')
                dest = shutil.move(source, target)
                if dest==target:
                    moved = True
                    reason = 'replaced'
                    logger.info('   replaced!')
            else:
                logger.info('   skipping...')
                reason = 'existing'
        else:
            logger.critical("   Target exists but it's not a file... Exiting.")
            reason = "target_is_not_file"

    else:
        logger.info('   moving...')
        dest=shutil.move(source, target)
        if dest==target:
            moved = True
            reason = "moved"
            logger.info('   moved!')

    return moved, reason

######################################################
#
######################################################
def file_backup_datetime(source, targetDir=None, fWRITE=True):
    source=Path(source).resolve()

    assert source.is_file()
    if targetDir:
        targetDir=Path(targetDir)
        if not targetDir.is_absolute():
            targetDir=source.parent / targetDir
    else:
        targetDir=source.parent

    if not targetDir.is_dir():
        print(f"{targetDir} does't exitsts. Please create it before continue")
        sys.exit(1)

    mtime=source.stat().st_mtime
    h_datetime=time.strftime('%Y-%m-%d_%H%M%S', time.localtime(mtime))
    fname = Path(f'{source.stem}_{h_datetime}{source.suffix}')
    _target = Path(targetDir / fname)

    if fWRITE:
        logger.info(f'backup file:', [f'from {source}', f'to   {_target}'])
        ret=shutil.copyfile(source, _target)
        if ret==_target:
            logger.info('   copied')
        else:
            logger.error('   ERROR')
    else:
        logger.info('NO Write was requested')

    return _target

######################################################
#
######################################################
def LnPath2String(source):
    return str(source)


######################################################
#
######################################################
def fileSizeRotation(source, max_size=1000000, max_files=5, targetDir=None, remove_source=False):
    source=Path(source)
    assert source.is_file()

    ndigits=len(str(max_files))
    if ndigits<2: ndigits=2
    # pdb.set_trace()
    sourceLen=len(str(source))+(ndigits+1)
    if not targetDir: targetDir = source.parent
    if max_files>0:
        my_range=list(range(max_files-1, 0, -1)) # [4, 3, 2, 1]
        for number in my_range:
            _source = Path(f'{targetDir}/{source.stem}_{number:0{ndigits}}{source.suffix}')
            _target = Path(f'{targetDir}/{source.stem}_{number+1:0{ndigits}}{source.suffix}')
            if _source.exists():
                logger.debug1(f'Moving   {_source} ---> {_target}')
                dest=shutil.move(_source, _target)



        # operate on current file copying/moving to last rotation number
        _target = Path(f'{targetDir}/{source.stem}_{1:0{ndigits}}{source.suffix}')
        if remove_source:
            logger.debug1(f'Moving   {source} ---> {_target}')
            ret=shutil.move(source, _target)
        else:
            # copy instead of move... to leave current file untouched
            logger.debug1(f'Copying  {source} ---> {_target}')
            ret=shutil.copyfile(source, _target)
            # if ret==_target:
            #     print('copied')
            # else:
            #     print('ERROR')


# inseriamo i miei comandi nella classe Path.
Path.copyTo     = LnPathCopy
Path.moveTo     = LnPathMoveFile
Path.toStr      = LnPath2String
Path.sizeRotate = fileSizeRotation
Path.backupDateTime   = file_backup_datetime
# Path.setLogger   = setLoggerLn # non serve perchè richiamata direttamente
