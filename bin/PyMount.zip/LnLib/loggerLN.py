
#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Version ......: 16-08-2020 10.34.13
#
# 05-11-2018: creato _printLog unico sia per console che per log
#
import sys, os, time
import shutil
import json, yaml
import types #  per il SimpleNamespace
import argparse #  per il Namespace
import pathlib # per il PosixPath

from pathlib import Path
if sys.version_info >= (3,0):
    unicode = str
# from LnLib.LnMonkeyFunctions import LnPathSizeRotate

###########################################
# - converte LnClass o LnDict in dict
###########################################
def toDict(data):
    # print (type(data))
    _myDict = {}
    dataType = str(type(data)).lower()

    if 'dotmap' in dataType:
        print ('dotamp')
        _myDict = data.toDict()


    elif 'lnclass' in dataType:
        print ('lnclass')
        for item in vars(data):
            _myDict[item] = getattr(data, item)

    else:
        _myDict = data

    return _myDict


##############################################################################
# - classe utile da mettere in qualche modulo.
##############################################################################
class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=info=debug=debug1=debug2=debug3=set_level=dummy

##############################################################################
# -
##############################################################################
class myLogger():
    levels={'CRITICAL':0, 'ERROR':1, 'WARNING':2, 'INFO':3, 'DEBUG1':4, 'DEBUG2':5, 'DEBUG3':6}

    def __init__(self, args):
        assert isinstance(args, dict)
        global C
        log=types.SimpleNamespace()

        # process dict_arguments
        C=args.color                if 'color' in args else None
        log.slevel=args['level']    if 'level' in args else 'INFO'
        log.modules=args['modules'] if 'modules' in args else []
        log.date=args['disp_date']  if 'disp_date' in args else False
        log.time=args['disp_time']  if 'disp_time' in args else False
        log.console=args['console'] if 'console' in args else False
        log.fullpath_module=args['disp_fullpath_module'] if 'disp_fullpath_module' in args else False
        log.rotation_nfiles=int(args['rotation_nfiles']) if 'rotation_nfiles' in args else 5
        log.rotation_filesize=int(args['rotation_filesize']) if 'rotation_filesize' in args else 10*1024*1024

        if log.rotation_filesize<10000: log.rotation_filesize=10000 # potrebbe andare in stack overflow con la open()
        log.ilevel = myLogger.levels[log.slevel.upper()]


        self.log=log
        self._filename=args['filename']

        self.open()


    def open(self):
        mode='a+' if self.log.rotation_nfiles else 'w'
        self.logger = open(self._filename, mode, encoding='utf-8')

            # Messaggio iniziale nel LOG
        self._printLog('INFO', '\n'*5,
                [
                    '-'*50,
                    f'- log_filename: {self._filename}',
                    f'- starting: {time.strftime("%Y/%m/%d %H:%M:%S")}',
                    f'- log level: {self.log.ilevel}',
                    f'- log_modules: {self.log.modules}',
                    f'- log_console: {self.log.console}',
                    f'- rotation_max_files: {self.log.rotation_nfiles}',
                    f'- rotation_max_file_size: {self.log.rotation_filesize}',
                    '-'*50,
                    ''
                ])



    def critical(self,  title, *args, **kwargs):
        ''' exit_code può essere passato con valore 0 nel caso si voglia
            evitare che il crontab generi una mail a fronte di un sys.exit(1).
            Invece ho notato che comunque crontab invia la mail...
        '''
        exit_code=kwargs.pop('exit_code', 1)
        self._printLog('CRITICAL', title, *args, **kwargs, console=True)
        self._printLog('CRITICAL', f'Exiting from program exit_code: {exit_code}', console=True)
        self.logger.flush()
        sys.exit(exit_code)

    def console(self, title, *args, **kwargs):
        self._printLog('INFO', title, *args, **kwargs, console=True)

    def error(self,  title, *args, **kwargs):
        self._printLog('ERROR', title, *args, **kwargs)

    def warning(self,  title, *args, **kwargs):
        self._printLog('WARNING', title, *args, **kwargs)

    def info(self,  title, *args, **kwargs):
        self._printLog('INFO', title, *args, **kwargs)

    def debug1(self,  title, *args, **kwargs):
        self._printLog('DEBUG1', title, *args, **kwargs)
    debug=debug1

    def debug2(self,  title, *args, **kwargs):
        self._printLog('DEBUG2', title, *args, **kwargs)

    def debug3(self,  title, *args, **kwargs):
        self._printLog('DEBUG3', title, *args, **kwargs)

        # me=__name__.rsplit('.', 1)[-1].upper()
        # self._printLog(me, title, *args, **kwargs)

    def _dummy(self, level=None, title=None, *args):
        pass

    def set_level(self, level):
        level=level.upper()
        try:
            self.log.ilevel=self.levels[level]
        except (Exception) as why:
            self.critical('required level', level, 'not valid!', str(why))
        self.debug3('setting log level to:', level, self.log.ilevel)


    def isLoggedModule(self, data):
        FOUND = False
        if self.log.modules in ([], ['*'], ['all']):
            FOUND = True
        else:
            for module in self.log.modules:
                if module.lower() in data.lower():
                    FOUND = True
                    break

        return FOUND

    def _printLog(self, level=None, title=None, *args, **kwargs):
        if not isinstance(title, str):
            title=str(title)
        assert isinstance(title, (str, unicode))

        # skip if out of the required level
        lvl_no=myLogger.levels[level]
        if lvl_no > self.log.ilevel: return

        if isinstance(title, (float, int)):
            title = f'{title}'
        # no_title = ' '*len(title)
        no_title = ' '*3

        if 'console' in kwargs and kwargs['console']==True:
            to_console = True
        else:
            to_console = False

        if 'print_yaml' in kwargs and kwargs['print_yaml']==True:
            print_yaml=True
        else:
            print_yaml=False


        caller = _getCaller(stackNum=3, modules=self.log.modules, fullpath_module=self.log.fullpath_module)
        caller = self._getCaller(stackNum=3)

        if level in ['CRITICAL']:
            pass # prosegui senza guardare il module filter
        elif not caller:
            return
        # elif not self.isLoggedModule(caller):

        disp_level = f'{level:6.6}' # format (min.max) chars


        # data e ora sono visualizzate su richiesta
        if self.log.date and self.log.time:
            now = time.strftime("%Y/%m/%d %H:%M:%S")

        elif self.log.date:
            now = time.strftime("%Y/%m/%d")

        elif self.log.time:
            now=time.strftime("%H:%M:%S")
        else:
            now=''

        NOW=f'{now} - ' if now else ''

        # log_prefix = f"{caller} {disp_level } -> "
        log_prefix = f"{NOW}{caller} {disp_level } -> "
        console_prefix = "      "
        console_prefix = f"{caller} -> "


        if not args: args=(' ')# per processare quando esiste solo il titolo
        for index, item in enumerate(args):
            if index > 0: title=no_title
            data = prepareData(title, item, print_yaml=print_yaml)

            for line in data:
                if self.log.console or to_console:
                    # in caso di critical scriviamo anche data e ora
                    text_0=log_prefix if level=='CRITICAL' else console_prefix
                    if C:
                        C.yellow(text=text_0, end='')
                        C.yellowH(text=line)
                    else:
                        print(text_0 + line)

                self.logger.write(log_prefix + line + '\n')

        self.logger.flush()  #  by Loreto:  01-11-2018 18.55.13

        # ---------------------
        # - logger file rotation
        # ---------------------
        if self.log.rotation_nfiles>1:
            file = Path(self._filename)
            if file.stat().st_size > self.log.rotation_filesize:
                self.logger.close()

                file.sizeRotate(
                                max_files=self.log.rotation_nfiles,
                                max_size=self.log.rotation_filesize,
                                remove_source=True
                                )

                #- clear file to size=0
                #- in questo modo se ho un tail sul file ... ma non è vero
                # file = open(self._filename,"r+")
                # file.truncate(0)
                # file.close()

                #- reopen logger file
                self.open()




    def _getCaller(self, stackNum=3):
        # set static variable max_caller_len
        if not getattr(_getCaller, 'max_caller_len', None):
           _getCaller.max_caller_len=0

        caller = sys._getframe(stackNum)
        programFile = caller.f_code.co_filename
        lineNumber  = caller.f_lineno
        funcName    = caller.f_code.co_name

        if funcName == '<module>': funcName = '__main__'
        fname = os.path.basename(programFile).split('.')[0]
        pkg=funcName if not self.log.fullpath_module else fname + '.' + funcName
        pkg = pkg.replace('ansible_module_', '')

        pkg_len=len(pkg)

        # calcolo MAX LEN
        if pkg_len>_getCaller.max_caller_len:
            _getCaller.max_caller_len=pkg_len

        # _caller = f"[{pkg:<15}:{lineNumber:4}]"
        _caller = f"[{pkg:<{_getCaller.max_caller_len}}:{lineNumber:4}]"

        if self.isLoggedModule(_caller):
            return _caller
        else:
            return None


def _getCaller(stackNum=3, modules=[], fullpath_module=False):
    # set static variable max_caller_len
    if not getattr(_getCaller, 'max_caller_len', None):
       _getCaller.max_caller_len=0

    caller = sys._getframe(stackNum)
    programFile = caller.f_code.co_filename
    lineNumber  = caller.f_lineno
    funcName    = caller.f_code.co_name

    if funcName == '<module>': funcName = '__main__'
    fname = os.path.basename(programFile).split('.')[0]
    pkg=funcName if not fullpath_module else fname + '.' + funcName
    pkg = pkg.replace('ansible_module_', '')

    pkg_len=len(pkg)

    # calcolo MAX LEN
    if pkg_len>_getCaller.max_caller_len:
        _getCaller.max_caller_len=pkg_len

    # _caller = f"[{pkg:<15}:{lineNumber:4}]"
    _caller = f"[{pkg:<{_getCaller.max_caller_len}}:{lineNumber:4}]"
    return _caller

def prepareData(title, args, print_yaml=False):
    data_list = []
    TAB=4*' '


    # - convert namespace to dict
    # print(type(args), args)
    if isinstance(args, (types.SimpleNamespace, argparse.Namespace)):
        args=vars(args)
    elif isinstance(args, (pathlib.PosixPath)):
        args=str(args)

    if isinstance(args, (list, tuple)):
        data_list.append(f'{title} [el={len(args)}]:')

        for index, item in enumerate(args):
            data = f'{TAB} - {item}'
            data_list.append(data)

    elif isinstance(args, dict): # anche DotMap?
        data_list.append(title)
        my_json = json.dumps(args, indent=4, sort_keys=True)
        my_yaml = yaml.dump(yaml.load(my_json, Loader=yaml.FullLoader), indent=4, sort_keys=True, default_flow_style=False)
        _my_dict=my_yaml if print_yaml else my_json
        for line in _my_dict.split('\n'):
            data_list.append(line)

    elif isinstance(args, (bool, int, float)):
        data = f'{title} {args}'
        data_list.append(data)

    elif args in ['']:
        data_list.append(title)

    elif not args.strip():
        data_list.append(title)

    else: # should be string....
        if '\n' in args:
            data_list.append(f'{title}')
            for line in args.split('\n'):
                data_list.append(f'{TAB} - {line}')
        else:
            data_list.append(f'{title} {args}')

    return data_list


def setLogger(dict_args):
    assert isinstance(dict_args, dict)
    log_status=dict_args.pop('log')
    if log_status:
        _logger=myLogger(dict_args)
    else:
        _logger=nullLogger()

    return _logger

# -------------------------------
# - Esempio di Inizializzazione del logger
# -------------------------------
if __name__ == '__main__':
    if inpArgs.log:
        params=dict(
            log=True,
            filename=f'/tmp/{prj_name}.log',
            console=inpArgs.log_console,
            log_level=config.logger.log_level,
            log_modules=inpArgs.log_modules,
            fullpath_module=config.logger.fullpath_module
            )
    else:
        params=dict(
            log=False,
            log_modules=inpArgs.log_modules,
            fullpath_module=config.logger.fullpath_module
            )

    lnLogger = setLogger(params)