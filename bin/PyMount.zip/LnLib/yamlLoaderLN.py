# #############################################
#
# updated by ...: Loreto Notarantonio
# Version ......: 12-08-2020 17.34.39
#
# #############################################

import  sys; sys.dont_write_bytecode=True
import  os

from    pathlib import Path
import  zipfile
import  io
import  yaml, json, re


def debuginfo(message):
    from inspect import getframeinfo, stack
    caller = getframeinfo(stack()[1][0])
    print (f"{caller.filename}:{caller.lineno} - {message}")


class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=info=debug=debug1=debug2=debug3 = dummy

#######################################################
# filename:  deve essere relative-path in quanto deve
#   poter essere letto anche all'interno dello zip file
#######################################################
def loadYamlFile(yaml_filename, fPRINT=False, resolve=False, my_logger=None):
    global logger
    logger=my_logger if my_logger else nullLogger()
    # check if I'm inside a ZIP file or directory
    _this_filepath=Path(sys.argv[0]).resolve()
    script_path=_this_filepath.parent # ... then up one level

    content=[]
    # import pdb; pdb.set_trace() # by Loreto
    if zipfile.is_zipfile(_this_filepath):
        _I_AM_ZIP    = True
        zip_filename = _this_filepath
        z = zipfile.ZipFile(zip_filename, "r")
        with z.open(yaml_filename) as f:
            _data = f.read()
        _buffer = io.TextIOWrapper(io.BytesIO(_data))# def get_config(yaml_filename):
        # contents  = io.TextIOWrapper(io.BytesIO(_data), encoding='iso-8859-1', newline='\n')# def get_config(yaml_filename):
        for line in _buffer:
            content.append(line)

    else: # qui devo mettere il path completo perchè non so quale sia la mia currDir
        yaml_filename=script_path / yaml_filename
        with open(yaml_filename, 'r') as f:
            content = f.readlines() # splitted in rows
            # content = f.read() # single string

    """ rimuoviamo le linee commentate
        perché nel caso volessi risolvere e variabili
        eviterei errori presenti nei commenti
    """
    if content: # it's a LIST containing file rows...
        rows = []
        for line in content:
            if not line.strip(): continue
            if line.strip()[0]=='#': continue
            rows.append(line)

        result = '\n'.join(rows)
        # content = yaml.safe_load(result) # non usa i constructors
        content = yaml.load(result, Loader=yaml.FullLoader) # non usa i constructors

    else:
        # print ('configuration file {0} NOT FOUND'.format(filename))
        debuginfo('configuration file {0} NOT FOUND'.format(filename))
        sys.exit(1)

    if resolve:
        content=processYamlData(content)

    if fPRINT:
        import json
        print(json.dumps(content, indent=4, sort_keys=True))
        debuginfo('Exiting as required...')
        sys.exit()
    return content




def processYamlData(data, prefix=r'${', suffix=r'}', errorOnNotFound=True):
    assert isinstance(data, (dict, str))
    global data_str, already_read_files, logger, error_OnNotFound

    error_OnNotFound=errorOnNotFound
    already_read_files = {}

    data_str = data if isinstance(data, str) else json.dumps(data)
    processed_vars = [] # variables already processed

    _prefix = prefix.replace('$', '\\$')
    _suffix = suffix.replace('$', '\\$')
    """prefix - suffix: variable must be suffixed by non unicode
                        characters to avoid parsing errors
                        tested and cut: $, {}, §, ...
    """
    # - search for variables
    strToFind = _prefix + r'(.*?)' + _suffix
    while True:
        var_names_list = re.findall(strToFind, data_str)
        var_names_list = [x for x in var_names_list if x.strip()] # ignore empty vars --> {{ }}
        var_names_list = [x for x in var_names_list if x not in processed_vars] # ignore already processed vars
        if not var_names_list: # process completed
            break

        var_name = var_names_list[0] # get the first variable
        var_value = _decode_variable(var_name) # decode and search for it
        if var_value:   # variable value FOUND
            # remove DQuote around the string created by json.dumps
            DQ = '"'
            _new_data = json.dumps(var_value, indent=4, sort_keys=True).strip('"')
            str_to_replace = prefix + var_name + suffix
            data_str = data_str.replace(str_to_replace, _new_data)
        else:
            if error_OnNotFound:
                msg = 'Variable {0} NOT FOUND'.format(prefix + var + suffix)
                logger.error(msg)
                debuginfo(msg)
                sys.exit()
            else:
                processed_vars.append(var_name)


    return yaml.load(data_str, Loader=yaml.FullLoader)
    # return yaml.safe_load(data_str)


def _decode_variable(var_name):
    _dict = yaml.load(data_str, Loader=yaml.FullLoader) # read currente data as dict

    if ':' in var_name:
        _fname, d_path = var_name.strip().split(':', 1) # format filename:key1.key2....
        if _fname.lower() in ('env:'): # format env:varname
            _value = os.environ.get(d_path, None)
            logger.debug(d_path, _value)
            # if not _value and error_OnNotFound:
            if _value and _value[1] == ':':
                _value = Path(_value).resolve() # elimina tutti i \\\\ eccedenti
            elif not _value and error_OnNotFound:
                # print('variable: "{}" NOT found.'.format(d_path))
                debuginfo(f'variable: "{d_path}" NOT found.')
                sys.exit(1)

            return str(_value)

        else:
            if _fname in already_read_files:
                _dict = already_read_files[_fname]

            # - altrimenti leggilo
            else:
                filename, ext = os.path.splitext(_fname)
                extensions = [ext] if ext else ['.yaml', '.yml']
                # read file
                _dict = None
                for ext in extensions:
                    file = os.path.abspath(os.path.join(base_dir, '{0}{1}'.format(filename, ext)))
                    if os.path.isfile(file):
                        with open(file, 'r') as fin:
                            _dict = yaml.load(fin, Loader=yaml.FullLoader)
                        already_read_files[_fname] = _dict
                        break

                if _dict is None:
                    raise IOError('File: {} NOT FOUND!'.format(file))


    elif '.' in var_name:
        d_path = var_name

    else:
        # un variabile senza prefisso... skip it
        return None


    # - moving through the dict tree
    ptr = _dict
    for item in d_path.strip().split('.'):
        if item in ptr:
            ptr = ptr[item]
        else:
            msg = 'key: {} not found in the dictionary'.format(d_path)
            raise Exception('ERROR {}'.format(msg))

    if ptr[1] == ':':
        ptr = Path(ptr).resolve() # elimina tutti i \\\\ eccedenti
        # if not ptr.exists() and errorOnPathNotFound:
        #     print('path: "{}" NOT found.'.format(ptr))
        #     sys.exit(1)

    return str(ptr)





