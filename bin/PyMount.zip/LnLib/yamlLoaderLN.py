# #############################################
#
# updated by ...: Loreto Notarantonio
# Version ......: 24-08-2020 12.30.39
#
# #############################################

import  sys; sys.dont_write_bytecode=True
import  os

from    pathlib import Path
import  zipfile
import  io
# import  yaml # PyYAML
# yaml_load=yaml.load
import  pyaml, yaml # https://pypi.org/project/pyaml/
import  json, re
# yaml_load=pyaml.safe_load

def debuginfo(message):
    from inspect import getframeinfo, stack
    caller=getframeinfo(stack()[1][0])
    print (f"{caller.filename}:{caller.lineno} - {message}")


class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=info=debug=debug1=debug2=debug3=dummy


# --------------------
class RecursiveNamespace: # without extending SimpleNamespace!
  @staticmethod
  def map_entry(entry):
    if isinstance(entry, dict):
      return RecursiveNamespace(**entry)

    return entry

  def __init__(self, **kwargs):
    for key, val in kwargs.items():
      if type(val) == dict:
        setattr(self, key, RecursiveNamespace(**val))
      elif type(val) == list:
        setattr(self, key, list(map(self.map_entry, val)))
      else: # this is the only addition
        setattr(self, key, val)



#######################################################
# filename:  deve essere relative-path in quanto deve
#   poter essere letto anche all'interno dello zip file
#######################################################
def loadYamlFile(yaml_filename, fPRINT=False, resolve=False, my_logger=nullLogger()):
    global logger
    logger=my_logger

    # check if I'm inside a ZIP file or directory
    _this_filepath=Path(sys.argv[0]).resolve()
    script_path=_this_filepath.parent # ... then up one level

    #---- read yaml file
    content=[]
    if zipfile.is_zipfile(_this_filepath):
        _I_AM_ZIP=True
        zip_filename=_this_filepath
        z=zipfile.ZipFile(zip_filename, "r")
        with z.open(yaml_filename) as f:
            _data=f.read()
        _buffer=io.TextIOWrapper(io.BytesIO(_data))# def get_config(yaml_filename):
        # contents =io.TextIOWrapper(io.BytesIO(_data), encoding='iso-8859-1', newline='\n')# def get_config(yaml_filename):
        for line in _buffer:
            content.append(line)

    else: # qui devo mettere il path completo perchè non so quale sia la mia currDir
        yaml_filename=script_path / yaml_filename
        with open(yaml_filename, 'r') as f:
            content=f.readlines() # splitted in rows
            # content=f.read() # single string


    """
        rimuoviamo le linee commentate
        perché nel caso volessi risolvere e variabili
        eviterei errori presenti nei commenti
    """
    """ content is a LIST..."""
    if content:
        rows=[]
        for line in content:
            if not line.strip(): continue
            if line.strip()[0]=='#': continue
            rows.append(line)

        """ content is a string..."""
        content='\n'.join(rows)

    else:
        debuginfo('configuration file {0} NOT FOUND'.format(filename))
        sys.exit(1)

    """ content will be a dictionary..."""
    if resolve:
        content=resolve_VARs(content)
    else:
        content=yaml.load(content, Loader=yaml.FullLoader) # non usa i constructors
        # content=pyaml.safe_load(content, Loader=yaml.FullLoader) # non usa i constructors

    if fPRINT:
        print(json.dumps(content, indent=4, sort_keys=True))
        print()
        print()
        # print(yaml.dump(content))
        pyaml.p(content, indent=4)
        debuginfo('Exiting as required...')
        sys.exit()

    """ return is a dictionary..."""
    return content



###################################################################
# Try to resolve internal variables ${xxxx}
#   ${name}
#   ${name.sub}
###################################################################
def resolve_VARs(data, prefix=r'${', suffix=r'}', exitOnNotFound=True):
    assert isinstance(data, (dict, str))

    # creiamo tre istanze di dati... str, dict, namespace
    data_str=data if isinstance(data, str) else json.dumps(data)
    data_dict=yaml.load(data_str, Loader=yaml.FullLoader)
    # data_dict=pyaml.safe_load(data_str, Loader=yaml.FullLoader)
    data_ns=RecursiveNamespace(**data_dict)

    processed_vars=[] # variables already processed

    _prefix=prefix.replace('$', '\\$')
    _suffix=suffix.replace('$', '\\$')
    """prefix - suffix: variable must be suffixed by non unicode
                        characters to avoid parsing errors
                        tested and cut: $, {}, §, ...
    """
    # - search for variables
    strToFind=_prefix + r'(.*?)' + _suffix
    while True:
        var_names_list=re.findall(strToFind, data_str)
        var_names_list=[x for x in var_names_list if x.strip()] # ignore empty vars --> {{ }}
        var_names_list=[x for x in var_names_list if x not in processed_vars] # ignore already processed vars
        if not var_names_list: # process completed
            break

        for var_name in var_names_list:

            if var_name.startswith('env:'):
                var_value=os.environ.get(var_name[4:], None)

            else:
                var_path=f'data_ns.{var_name}'#- create namespace path for variable
                try:
                    var_value=eval(var_path)
                except (AttributeError) as e:
                    print(str(e))
                    var_value=None

            if not var_value and exitOnNotFound:
                msg=f'Cannot resolve variable {var_name} in yaml file'
                logger.error(msg)
                debuginfo(msg)
                sys.exit()
            else:
                processed_vars.append(var_name)

            str_to_replace=f'{prefix}{var_name}{suffix}'
            if isinstance(var_value, list): var_value=str(var_value)
            if isinstance(var_value, RecursiveNamespace): var_value= json.dumps(vars(var_value))
            try:
                data_str=data_str.replace(str_to_replace, var_value)
            except (Exception) as e:
                print(str(e))
                import pdb; pdb.set_trace() # by Loreto
                sys.exit()

    return yaml.load(data_str, Loader=yaml.FullLoader)
    # return pyaml.safe_load(data_str, Loader=yaml.FullLoader)

