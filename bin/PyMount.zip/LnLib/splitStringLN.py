#!/usr/bin/python2.7
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Version ......: 02-07-2020 17.23.28


# #################################################################
# #  link:  http://stackoverflow.com/questions/4998629/python-split-string-with-multiple-delimiters
# #  splitString with multiple delimiters
# #  delimiters:    LIST/TUPLE of delimiters
# #  Example:
# #     l='/dev/sda1: LABEL="TOSHIBA EXT" UUID="843671A53671993E" TYPE="ntfs" PARTUUID="7fcb449d-01"'
# #     stringSplitRE(l, (':', '=', '"'))
# #     out: ['/dev/sda1', ' LABEL', '', 'TOSHIBA EXT', ' UUID', '', '843671A53671993E', ' TYPE', '', 'ntfs', ' PARTUUID', '', '7fcb449d-01', '']
# #################################################################
def stringSplitRE(string, delimiters, maxsplit=0, remove_empty=True, strip_elements=True):
    import re
    regexPattern = '|'.join(map(re.escape, delimiters))
    re.compile(regexPattern) #per velocizzare ma solo se il pattern è sempre lo stesso
    result=re.split(regexPattern, string, maxsplit)
    if remove_empty:
        result = [x for x in result if x.strip()] #  remove empty elements
    if strip_elements:
        result = [x.strip() for x in result if x.strip()] #  strip elements
    return result

##################################################
# prende una stringa e la converte in un dict
# k:v due parametri per volta
#   1.1.1.1 via 192.168.1.1 dev eth0 src 192.168.1.31 uid 1000
#     ...con il comando:
#   splitText(iproute[0], start_word=1, nwords=2, Dict=True)
#      ...diventa
#   {'via': '192.168.1.1', 'dev': 'eth0', 'src': '192.168.1.31', 'uid': '1000'}
##################################################
    def splitText(self, string, start_word=0, nwords=2, Dict=False):
        if isinstance(string, (str)):
            words=string.split()
        else:
            words=string
        words=words[start_word:]
        grouped_words = [' '.join(words[i: i + nwords]) for i in range(0, len(words), nwords)]
        if Dict and nwords==2:
            myDict={}
            for item in grouped_words:
                k, v = item.split()
                myDict[k.strip()]=v.strip()
            return myDict

        return grouped_words