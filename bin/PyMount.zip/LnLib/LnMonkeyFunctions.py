#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Version ......: 04-07-2020 07.55.16
#
# Scope:  aggiunge dei metodi alle classi di sistema
#
# ######################################################################################
import sys
import shutil

from pathlib import Path
from time import strftime

################################################
################################################
def LnMonkeySet(lnLogger):
    global logger
    logger = lnLogger

################################################
################################################
def LnPathCopy(source, target, logger):
    #assert Path(source).is_file()
    '''
    alternative of Path.copy
    copyfile only if size or mtime ad differents
    params:
        target : target
        vSize  : verify fileSize
        vMTime : verify mTime
    '''

    source = Path(source)
    target = Path(target)
    logger.info('working on files: {} - {}'.format(source._str, target._str))
    diffSize, diffTime = False, False
    src = source.stat()
    tgt = src # default nel caso target non esista.
    if target.exists():
        tgt = target.stat()
        diffSize = (src.st_size != tgt.st_size)
        diffTime = (src.st_mtime > tgt.st_mtime)

    logger.info('diffTime value: {0} <--> {1}'.format(src.st_mtime, tgt.st_mtime))
    logger.info('diffSize value: {0} <--> {1}'.format(src.st_size, tgt.st_size))

    if diffTime:
        logger.info('copying file...')
        shutil.copy(source._str, target._str)
    elif diffSize:
        logger.warning('same DATETIME but different SIZE... NOT copied')
    else:
        logger.info('DATETIME and SIZE are equals. copy skipped...')


################################################
#  by Loreto:  16-04-2020 07.29.01
################################################
def LnPathMoveFile(source, target, create_parent=True, replace=False):
    assert source.is_file()
    source = Path(source)
    target = Path(target)
    logger.info('''moving file:
                        from {source}
                        to   {target}'''.format(**locals()))

    # create tree if required and not exists
    if create_parent:
        target.parent.mkdir(parents=True, exist_ok=True)

    moved = False
    reason = '___'
    if target.exists():
        if target.is_file():
            logger.info('File already exists on destination path.')
            if replace:
                logger.info('Moving and Replacing...')
                dest = shutil.move(str(source), str(target))
                if dest==str(target):
                    moved = True
                    reason = 'replaced'
            else:
                logger.info('Skipping...')
                reason = 'existing'
        else:
            logger.abend("Target exists but it's not a file... Exiting.")
            reason = "target_is_not_file"

    else:
        logger.info('moving file...')
        dest=shutil.move(str(source), str(target))
        if dest==str(target):
            moved = True
            reason = "moved"

    return moved, reason

######################################################
#
######################################################
def LnPathBackup(source, targetDir=None, logger=None):
    assert source.is_file()

    if not targetDir: targetDir = source.parent
    fname = '{NAME}_{DATE}{EXT}'.format(NAME=str(source.parent.name), DATE=strftime('%Y-%m-%d_%H_%M'), EXT=str(source.suffix))
    backupFile = Path(targetDir).joinpath(fname)
    backupFile = Path(backupFile)
    shutil.copy(str(source), str(backupFile))

######################################################
#
######################################################
def LnPath2String(source):
    return str(source)


def LnPathSizeRotate(source, max_size=1000000, max_files=5, targetDir=None, fDEBUG=False):
    assert source.is_file()

    if not targetDir: targetDir = source.parent

    my_range=list(range(max_files-1, 0, -1)) # [4, 3, 2, 1]
    for number in my_range:
        _source = Path(f'{targetDir}/{source.stem}_{number:03}{source.suffix}')
        _target = Path(f'{targetDir}/{source.stem}_{number+1:03}{source.suffix}')
        if _source.exists():
            if fDEBUG: print(f'Moving {_source} and Replacing {_target}...')
            dest=shutil.move(_source, _target)
            if not dest==_target:
                moved = True
                reason = 'replaced'

        # copy instead of move... to leave current file untouched
        # copy current to last rotation number
    _target = Path(f'{targetDir}/{source.stem}_{1:03}{source.suffix}')
    if fDEBUG: print(f'Copying {source} and Replacing {_target}...')
    shutil.copyfile(source, _target)



# inseriamo i miei comandi nella classe Path.
Path.copyTo     = LnPathCopy
Path.backup     = LnPathBackup
Path.moveTo     = LnPathMoveFile
Path.LnSet      = LnMonkeySet
Path.toStr      = LnPath2String
Path.sizeRotate = LnPathSizeRotate
