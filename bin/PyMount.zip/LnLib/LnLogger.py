
#!/usr/bin/python2.7
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Version ......: 04-07-2020 16.18.47
#
# 05-11-2018: creato _printLog unico sia per console che per log
#
import sys, os, time
import shutil
import json, yaml
import pdb
import types #  per il SimpleNamespace
from pathlib import Path
if sys.version_info >= (3,0):
    unicode = str
# from LnLib.LnMonkeyFunctions import LnPathSizeRotate

###########################################
# - converte LnClass o LnDict in dict
###########################################
def toDict(data):
    # print (type(data))
    _myDict = {}
    dataType = str(type(data)).lower()

    if 'dotmap' in dataType:
        print ('dotamp')
        _myDict = data.toDict()


    elif 'lnclass' in dataType:
        print ('lnclass')
        for item in vars(data):
            _myDict[item] = getattr(data, item)

    else:
        _myDict = data

    return _myDict


##############################################################################
# - classe utile da mettere in qualche modulo.
##############################################################################
class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=info=debug1=debug2=debug3=set_level=dummy

class myLogger():
    levels={'CRITICAL':0, 'ERROR':1, 'WARNING':2, 'INFO':3, 'DEBUG1':4, 'DEBUG2':5, 'DEBUG3':6}

    def __init__(self, filename,
                        console=False,
                        log_level='INFO',
                        log_modules=[],
                        fullpath_module=False,
                        log_date=False,
                        log_time=False,
                        color=None):
        global C
        self._filename=filename
        self._date_time_format  = '%m-%d %H:%M:%S'
        self._log_date   = log_date
        self._log_time   = log_time
        self._log_modules = log_modules
        self._fullpath_module=fullpath_module
        self._rotation_max_file_size=10*1024*1024
        # self._rotation_max_file_size=5000
        self._rotation_max_files=5

        self._console = console
        self._log_level = myLogger.levels[log_level.upper()]
        C = color
        self.open(self._filename)


    def open(self, file):
        self.logger = open(self._filename, 'w', encoding='utf-8')

            # Messaggio iniziale nel LOG
        self._printLog('INFO', '\n'*5,
                [
                    '-'*50,
                    f'- log_filename: {self._filename}',
                    f'- starting: {time.strftime("%Y/%m/%d %H:%M:%S")}',
                    f'- log level: {self._log_level}',
                    f'- log_modules: {self._log_modules}',
                    f'- log_console: {self._console}',
                    f'- rotation_max_files: {self._rotation_max_files}',
                    f'- rotation_max_file_size: {self._rotation_max_file_size}',
                    '-'*50,
                    ''
                ])
        # self._printLog('INFO', "ciao", vars(self))



    def critical(self,  title, *args, **kwargs):
        self._printLog('CRITICAL', title, *args, **kwargs, console=True)
        self._printLog('CRITICAL', 'Exiting from program', console=True)
        self.logger.flush()
        sys.exit(1)

    def console(self, title, *args, **kwargs):
        self._printLog('INFO', title, *args, **kwargs, console=True)

    def error(self,  title, *args, **kwargs):
        self._printLog('ERROR', title, *args, **kwargs)

    def warning(self,  title, *args, **kwargs):
        self._printLog('WARNING', title, *args, **kwargs)

    def info(self,  title, *args, **kwargs):
        self._printLog('INFO', title, *args, **kwargs)

    def debug1(self,  title, *args, **kwargs):
        self._printLog('DEBUG1', title, *args, **kwargs)

    def debug2(self,  title, *args, **kwargs):
        self._printLog('DEBUG3', title, *args, **kwargs)

    def debug3(self,  title, *args, **kwargs):
        self._printLog('DEBUG3', title, *args, **kwargs)


    def _dummy(self, level=None, title=None, *args):
        pass

    def set_level(self, level):
        level=level.upper()
        try:
            self._log_level=self.levels[level]
        except (Exception) as why:
            self.critical('required level', level, 'not valid!', str(why))
        self.debug3('setting log level to:', level, self._log_level)


    def isLoggedModule(self, data):
        FOUND = False
        if self._log_modules in ([], ['*'], ['all']):
            FOUND = True
        else:
            for module in self._log_modules:
                if module.lower() in data.lower():
                    FOUND = True
                    break

        return FOUND

    def _printLog(self, level=None, title=None, *args, **kwargs):
        if not isinstance(title, str):
            title=str(title)
        assert isinstance(title, (str, unicode))

        # skip if out of the required level
        lvl_no=myLogger.levels[level]
        if lvl_no > self._log_level: return

        # import pdb; pdb.set_trace()
        if isinstance(title, (float, int)):
            title = f'{title}'
        no_title = ' '*len(title)
        no_title = ' '*3

        if 'console' in kwargs and kwargs['console']==True:
            to_console = True
        else:
            to_console = False


        caller = _getCaller(stackNum=3, modules=self._log_modules, fullpath_module=self._fullpath_module)

        if level in ['CRITICAL']:
            pass # prosegui senza guardare il module filter
        elif not self.isLoggedModule(caller):
            return

        disp_level = f'{level:6.6}' # format (min.max) chars


        # l'ora forse non serve in quanto indicata all'inizio del logger
        if self._log_date and self._log_time:
            now = time.strftime("%Y/%m/%d %H:%M:%S")

        elif self._log_date:
            now = time.strftime("%Y/%m/%d")

        elif self._log_time:
            now=time.strftime("%H:%M:%S")
        else:
            now=''

        NOW=f'{now} - ' if now else ''

        log_prefix = f"{caller} {disp_level } -> "
        log_prefix = f"{NOW}{caller} {disp_level } -> "
        console_prefix = f"{caller} -> "


        if not args: args=(' ')# per processare quando esiste solo il titolo
        for index, item in enumerate(args):
            if index > 0: title=no_title
            data = prepareData(title, item)

            for line in data:
                if self._console or to_console:
                    # in caso di critical scriviamo anche data e ora
                    text_0=log_prefix if level=='CRITICAL' else console_prefix
                    if C:
                        C.yellow(text=text_0, end='')
                        C.yellowH(text=line)
                    else:
                        print(text_0 + line)

                self.logger.write(log_prefix + line + '\n')

        self.logger.flush()  #  by Loreto:  01-11-2018 18.55.13

        # ---------------------
        # - logger file rotation
        # ---------------------
        file = Path(self._filename)
        if file.stat().st_size > self._rotation_max_file_size:

            file.sizeRotate(
                            max_files=self._rotation_max_files,
                            max_size=self._rotation_max_file_size,
                            fDEBUG=True
                            )

            #- clear file to size=0
            #- in questo modo se ho un tail sul file, rimane attivo
            self.logger.close()
            file = open(self._filename,"r+")
            file.truncate(0)
            file.close()

            #- reopen logger file
            self.open(self._filename)




def _getCaller(stackNum=3, modules=[], fullpath_module=False):
    # pdb.set_trace()
    # set static variable max_caller_len
    if not getattr(_getCaller, 'max_caller_len', None):
       _getCaller.max_caller_len=0

    caller = sys._getframe(stackNum)
    programFile = caller.f_code.co_filename
    lineNumber  = caller.f_lineno
    funcName    = caller.f_code.co_name

    if funcName == '<module>': funcName = '__main__'
    fname = os.path.basename(programFile).split('.')[0]
    # pkg = fname + '.' + funcName
    pkg=funcName if not fullpath_module else fname + '.' + funcName
    pkg = pkg.replace('ansible_module_', '')

    pkg_len=len(pkg)

    # calcolo MAX LEN
    if pkg_len>_getCaller.max_caller_len:
        _getCaller.max_caller_len=pkg_len

    # _caller = f"[{pkg:<15}:{lineNumber:4}]"
    _caller = f"[{pkg:<{_getCaller.max_caller_len}}:{lineNumber:4}]"
    return _caller

def prepareData(title, args):
    data_list = []
    TAB=4*' '

    # - convert namespace to dict
    if isinstance(args, (types.SimpleNamespace)):
        args=vars(args)

    if isinstance(args, (list, tuple)):
        # if len(args)==1:
            # data_list.append(f'{title}')
            # data_list.append(f'{TAB}{args[0]}')
        # elif len(args)<51:
        #     data_list.append(f'{title}')
        # else:
            # data_list.append(f'{title} [el={len(args)}]:')
        data_list.append(f'{title} [el={len(args)}]:')

        for index, item in enumerate(args):
            # data = f'{TAB}[{index:04}] - {item}'
            data = f'{TAB} - {item}'
            data_list.append(data)

    elif isinstance(args, dict): # anche DotMap?
        # data_list.append(title + '[dict]:')
        data_list.append(title)
        my_json = json.dumps(args, indent=4, sort_keys=True)
        my_yaml = yaml.dump(yaml.load(my_json, Loader=yaml.FullLoader), default_flow_style=False)
        for line in my_json.split('\n'):
            data_list.append(line)

    elif isinstance(args, (bool, int, float)):
        data = f'{title} {args}'
        data_list.append(data)

    elif args in ['']:
        data_list.append(title)

    elif not args.strip():
        data_list.append(title)

    else: # should be string....
        if '\n' in args:
            data_list.append(f'{title}')
            for line in args.split('\n'):
                data_list.append(f'{TAB} - {line}')
        else:
            data_list.append(f'{title} {args}')

    return data_list


def setLogger(filename, **kwargs):
    if filename:
        _logger=myLogger(filename, **kwargs)
    else:
        _logger=nullLogger()
        # _logger=nullLogger(**kwargs)

    return _logger

# -------------------------------
# - Esempio di Inizializzazione del logger
# -------------------------------
if __name__ == '__main__':
    if inpArgs.log:
        log_file=f'/tmp/{prj_name}.log'
        params=dict(
            console=inpArgs.log_console,
            log_level=config.logger.log_level,
            log_modules=inpArgs.log_modules,
            fullpath_module=config.logger.fullpath_module
            )
    else:
        log_file=None
        params=dict(
            log_modules=inpArgs.log_modules,
            fullpath_module=config.logger.fullpath_module
            )

    lnLogger = setLogger(filename=log_file, **params)