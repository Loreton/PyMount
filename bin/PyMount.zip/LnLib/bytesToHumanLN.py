#!/usr/bin/python2.7
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Version ......: 18-06-2020 11.48.39




def bytes2H(num, kib=True):
    """
    this function will convert bytes to MB.... GB... etc
    """
    if kib:
        step_unit = 1024.0
        units=['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB']
    else:
        step_unit = 1000.0 #1024 bad the size
        units=['B', 'KB', 'MB', 'GB', 'TB']

    for unit in units:
        if num < step_unit:
            # return "%3.1f %s" % (num, unit)
            return "{num:3.1f} {unit}".format(**locals())
        num /= step_unit


