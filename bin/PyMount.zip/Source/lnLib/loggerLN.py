#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Date .........: 2021-05-25
#
import sys; sys.dont_write_bytecode = True
import os, time
from pathlib import Path
# import logging.config, coloredlogs
import logging.config, colorlog
if sys.version_info >= (3,0):
    unicode = str
import types #  per il SimpleNamespace
import argparse #  per il Namespace
import pathlib # per il PosixPath
# from inspect import getframeinfo, stack
import  inspect

import yaml, pyaml
import json
this=sys.modules[__name__]

from configurationLoaderLN import Main as LoadConfigFile
class LnClass():
    pass
gVars=LnClass()



class noConsoleFilter(logging.Filter):
    def filter(self, record):
        print("filtering!")
        return not (record.levelname == 'INFO') & ('no-console' in record.msg)



class ContextFilter(logging.Filter):
    def filter(self, rec):
        pkg=f'{rec.module}.{rec.funcName}'

        fDEBUG=False

        pkg_lower=pkg.lower()
        if fDEBUG:
            print(f'ContextFilter - {pkg_lower}')

        # filtro dei moduli

        # exclude è prioritario
        for module in gVars.exclude_modules:
            if fDEBUG:
                print(f'ContextFilter - {module}')
            if module.lower() in pkg_lower:
                return False

        if gVars.include_modules:
            for module in gVars.include_modules:
                if module.lower() in pkg_lower:
                    return True
            return False

        else:
            return True


        return False



########################################################
#  Custom Logger
########################################################
class CustomLogger(logging.Logger):

    def __init__(self, name):
        super(CustomLogger, self).__init__(name)

    def new_logger_method(self, caller=None):
        self.info("new_logger_method() called from: {}.".format(caller))

    def getFileHandler(self):
        for handler in self.handlers:
            if 'FileHandler' in str(handler):
                return handler
        return None

    def critical(self, title, *args, **kwargs):
        self._printLog(logging.critical, title, *args, **kwargs)
        sys.exit(1)

    def debug(self, title, *args, **kwargs):
        return self._printLog(logging.debug, title, *args, **kwargs)

    def error(self, title, *args, **kwargs):
        _data=self._printLog(logging.error, title, *args, **kwargs)
        if 'exit' in kwargs and kwargs['exit']:
            sys.exit(1)
        return _data

    def warning(self, title, *args, **kwargs):
        return self._printLog(logging.warning, title, *args, **kwargs)

    def info(self, title, *args, **kwargs):
        return self._printLog(logging.info, title, *args, **kwargs)

    def info_2(self, title, *args, **kwargs):
        # self._printLog(logging.info, title, *args, **kwargs)
        logging.info(title, stacklevel=3)

    def callerFunc(self, stacknum=1, fDEBUG=False):
        if fDEBUG:
            import traceback
            x=traceback.extract_stack()
            # y=traceback.format_list(x)
            # print(len(x))
            # for line in y:
            #     print(line)

            print('-'*40)
            for i in range(len(x)): print(i, inspect.stack()[i].function, inspect.stack()[i].lineno)

            print('-'*40)
            print(stacknum, inspect.stack()[stacknum].function, inspect.stack()[stacknum].lineno)
            print('-'*40)

        caller=inspect.stack()[stacknum]

        fname=caller.filename.rsplit('.', 1)[0]
        funcname=os.sep.join(fname.split(os.sep)[-2:])
        # funcname=os.sep.join(fname.split(os.sep)[-2:])
        msg=f"{funcname}:{caller.lineno}"
        # msg=f"{caller.function}:{caller.lineno}"
        return msg



    def _printLog(self, my_logger, title, *args, **kwargs):
        if self.fNULL_LOG: return None
        stackLEVEL=4

        if isinstance(title, str):
            #todo: non riporta bene il called by
            if title.lower().startswith('entering'):
                caller_func=self.callerFunc(stacknum=stackLEVEL)
                title=f"Entering... [Called by: {caller_func}]"

            if title.lower().startswith('leaving'):
                caller_func=self.callerFunc(stacknum=stackLEVEL)
                title=f"Leaving... [Returning to: {caller_func}]"

        stack_offset=kwargs.get('stack_offset', 0)
        print_yaml=kwargs.get('yaml', False)
        print_stack=kwargs.get('print_stack', False)
        to_console=kwargs.get('console', False) # NOT used

        stackLEVEL+=stack_offset

        if isinstance(title, (float, int)):
            title = f'{title}'
        elif not isinstance(title, str):
            title=str(title)

        no_title = ' '*3


        if not args: args=(' ')# per processare quando esiste solo il titolo
        data=[title]

        for index, item in enumerate(args):
            if index > 0: title=no_title
            _new=self._prepareData(item, print_yaml=print_yaml)
            """
                se l'ultimo item ha un ':' finale gli leghiamo
                il primo item del successivo args
                supponendo che vadano congiunti
            """
            if _new and _new[0] is None: _new[0] = 'None'
            if data[-1].strip().endswith(':') :
                _new[0]=f"{str(data[-1]).rstrip()} {str(_new[0]).strip()}" # move data[-1] in _new[0]
                del data[-1]
            data.extend(_new)

            """ print STACK_TRACE """
            if print_stack:
                import traceback
                data.append('')
                data.append(f'------------- stack trace [START] level: {stackLEVEL}')
                # data.append(f'stacklevel: {stackLEVEL}')
                _tb_appo=traceback.format_exc().splitlines()
                for line in _tb_appo:
                    data.extend(line.split('\n'))
                data.append('------------- stack trace [END]')
                data.append('')


        # - real Writing log lines
        data=[i for i in data if i.strip()]
        if data:
            my_logger(data[0], stacklevel=stackLEVEL)
            if to_console: print(data[0])
            for line in data[1:]:
                my_logger(f'  {line}', stacklevel=stackLEVEL)
                if to_console: print(line)


        return data

    def _prepareData(self, args, print_yaml=False):
        data_list = []
        TAB=2*' '

        if isinstance(args, (types.SimpleNamespace, argparse.Namespace)):
            args=vars(args)
        elif isinstance(args, (pathlib.PosixPath, type)):
            args=str(args)
        elif isinstance(args, set):
            args=list(args)

        # try to convert a json data to dict
        if isinstance(args, str) and '{' in args:
            try:
                args=json.loads(args)
            except:
                pass # args is just a str

        if isinstance(args, (list, tuple)):
            data_list.append(f'[items={len(args)}]')

            for index, item in enumerate(args):
                if isinstance(item, str) and '\n' in item:  #  by Loreto:  15-02-2021 16.02.33
                    for item1 in item.split('\n'):
                        data = f'{TAB} - {item1}'
                        data_list.append(f'{TAB} {data}')
                else:
                    data = f'{TAB} - {item}'
                    data_list.append(data)

        elif isinstance(args, dict):
            def is_jsonable(x):
                try:
                    json.dumps(x)
                    return True
                except (Exception) as e:
                    return str(e)

            _d={} # per evitare di modificare l'originale...  #  by Loreto:  01-04-2021 14.21.53
            for key,value in args.items():
                test=is_jsonable(value)
                if test is True:
                    _d[key]=value
                else:
                    # _d[key]=f"removed due to: {test} - value: {value}"
                    _d[key]=f"object: {value} - not unpacked due to: {test}"
                    # _d[key]=str(value)

            try:
                my_json = json.dumps(_d, indent=4, sort_keys=True)
                my_yaml = yaml.dump(yaml.load(my_json, Loader=yaml.FullLoader), indent=4, sort_keys=True, default_flow_style=False)
            except Exception as e:
                data_list.append('Error printing dictionary:')
                data_list.append(f'{TAB} {str(e)}')
                my_json=str(args)
                my_yaml=str(args)


            _my_dict=my_yaml if print_yaml else my_json
            for line in _my_dict.split('\n'):
                data_list.append(f'{TAB} {line}')


        elif isinstance(args, (bool, int, float)):
            data_list.append(str(args))

        elif args in ['']:
            pass


        elif isinstance(args, (str)):
            if '\n' in args:
                for line in args.split('\n'):
                    data_list.append(f'{TAB} - {line}')
            else:
                data_list.append(args)

        else:
            data_list.append(args)

        if not data_list:
            data_list.append("")
        return data_list









LAST_PKG_LEN=0
def calculate_caller_length(module, funcName):
    global LAST_PKG_LEN

    orig_module=module
    orig_func=funcName

    pkg=(f'{module}.{funcName}')
    pkg_len=len(pkg)

    left_align=False
    prefix=''
    if MAX_CALLER_LENGTH>0:
        module_len=len(module)
        if pkg_len>LAST_PKG_LEN:
            LAST_PKG_LEN=pkg_len
            if LAST_PKG_LEN>MAX_CALLER_LENGTH:
                LAST_PKG_LEN=MAX_CALLER_LENGTH
                if left_align:
                    prefix='../'

        max_module_len=LAST_PKG_LEN-(len(funcName) + len(prefix) +1)
        if left_align:
            module=(module+' '*50)[0:max_module_len]+prefix # prende la parte  iniziale del nome
            module=prefix+module
        else:
            module=prefix+(' '*50+module)[-max_module_len:] # prende la parte  finale del nome
            module+=prefix


    pkg=(f'{module}.{funcName}')
    # print(f'E - {orig_module:<25}  {orig_func:<10} - {max_module_len:03}.{LAST_PKG_LEN:03}.{pkg_len:03}: [{pkg}] {len(pkg)}')
    return pkg



########################################################
#
########################################################
def record_factory(*args, **kwargs):
    record = original_record_factory (*args, **kwargs)
    record.custom_attribute = 0xdecafbad # non so a cosa serva....
    '''
    https://docs.python.org/3.8/library/logging.html#logrecord-attributes
    module=record.module # Module (name portion of filename).
    name=record.module # Name of the logger used to log the call.
    name=record.pathname # Full pathname of the source file where the logging call was issued (if available).
    name=record.process # Process ID (if available).
    name=record.processName # Process name (if available).
    '''
    fDEBUG=False
    if fDEBUG:
        for item in args:
            if "chat_ids:" in str(item):
                break

    if record.funcName=='<module>':
        record.funcName = '__main__'
        record.name = '__main__'



    fDEBUG=False
    if fDEBUG:
        print(f'record_factory - {pkg}')
    '''
    if record.msg=='xxxentering':
        import pdb; pdb.set_trace() # by Loreto
    '''

    pkg=calculate_caller_length(record.module, record.funcName)
    record.ln_caller=f"{pkg}:{record.lineno:4}"

    return record

original_record_factory=logging.getLogRecordFactory()






########################################################
#
########################################################
def setup_logging(configuration_file, log_filename,
            console_level='critical',
            default_level=logging.DEBUG,
            env_key='LnLogger'):
    global MAX_CALLER_LENGTH

    # ------------------------------
    # -     record factory start
    logging.setLogRecordFactory(record_factory)
    # -     record factory end
    # ------------------------------

    script_path=Path(sys.argv[0]).resolve()
    os.chdir(script_path.parent)
    """ move to prj folder to work with relative paths"""


    extension = script_path.suffix
    if extension=='.zip':
        config=LoadConfigFile(filename=configuration_file)
    else:
        with open(configuration_file, 'rt') as f:
            try:
                config = yaml.safe_load(f.read())
            except Exception as e:
                print(e)
                print('Error in Logging Configuration. Using default configs')
                sys.exit(1)


    if config:
        gVars.loggers=list(config['loggers'].keys())
        """ MAX_CALLER_LENGTH: max len per il nome del caller ln_caller"""
        if 'ln_data' in config:
            MAX_CALLER_LENGTH=config['ln_data'].get('max_caller_len', 0)
            gVars.last_caller_len=0
            ms=config['ln_data'].get('milliseconds', False)
        else:
            MAX_CALLER_LENGTH=0 # no caller padding
            gVars.last_caller_len=0

        # replace configurated filename with one passed as parameter
        if log_filename:
            log_dir=log_filename.parent

            if not log_dir.is_dir():
                os.makedirs(log_dir)
            _handlers=['unique', 'debug', 'info', 'warning', 'error', 'critical']
            for hndl in _handlers:
                name=f'{hndl}_file_handler'
                if name in config['handlers']:
                    if hndl=='unique':
                        config['handlers'][name]['filename']=log_filename
                    else:
                        _fname=f'{log_filename.stem}_{hndl}{log_filename.suffix}'
                        config['handlers'][name]['filename']=f'{log_dir}/{_fname}'
                        # print(config['handlers'][name]['filename'])


        config['handlers']['console']['level']=getattr(logging, console_level.upper())
        logging.config.dictConfig(config)
        # coloredlogs.install(milliseconds=ms) # non va bene perché mi altera lo stacklevel nel log

    else:
        print(f'File: {configuration_file} NOT found....')
        sys.exit(1)



########################################################
#  MAIN
#  the first call must contain logger_name
#   (saved in gVars.my_logger_name end in env_key)
#  the other calls will use the same logger
########################################################
def getLogger(logger_name=None,
                configuration_file=None,
                log_filename=None,
                null_log=False,
                exclude_modules=[],
                include_modules=[],
                console_level='critical',
                env_key='Ln_Logger_Name'):

    """
        Multiple calls to logging.getLogger('someLogger')
        return a reference to the same logger object
    """
    if hasattr(this, 'Ln_Logger_Name'):
        return logging.getLogger(gVars.Ln_Logger_Name)
    else:
        gVars.Ln_Logger_Name=logger_name
        os.environ[env_key]=logger_name
        gVars.include_modules=include_modules
        gVars.exclude_modules=exclude_modules


    logging_class=logging.getLoggerClass()  # store the current logger factory for later
    logging._acquireLock()  # use the global logging lock for thread safety
    try:
        logging.setLoggerClass(CustomLogger)  # temporarily change the logger factory

        filename=log_filename.resolve()
        # log_dir=filename.parent
        setup_logging(configuration_file, log_filename=filename, console_level=console_level)
        """Multiple calls to logging.getLogger('someLogger')
        return a reference to the same logger object
        logger_name è il nome definito nel file di log_config.loggers
        """
        logger=logging.getLogger(logger_name)
        logger.propagate = False
        logger.log_dir=filename.parent
        logger.filename_full=filename
        logger.filename_name=filename.stem
        logger.fNULL_LOG=null_log



        if len(logger.handlers)==0:
            print()
            print('   no handlers, probabilmente non hai definito')
            print(f'   il nome del logger: {logger_name}')
            print(f'   nel file: {configuration_file}')
            print()
            print('     Defined logger names:')
            for name in gVars.loggers:
                print('      ', name)
            print()
            sys.exit()

        # i filtri vanno agganciati all'handler
        for hndl in logger.handlers:
            if 'StreamHandler' in str(hndl):
                hndl.addFilter(ContextFilter())

        logging.setLoggerClass(logging_class)  # be nice, revert the logger factory change
        logger.info('\n'*5,
                [
                    '-'*50,
                    f'- starting: {time.strftime("%Y/%m/%d %H:%M:%S")}',
                    f'- log_dir: {logger.log_dir}',
                    f'- exclude modules: {gVars.exclude_modules}',
                    f'- include modules: {gVars.include_modules}',
                    f'- log_console: {console_level}',
                    '-'*50,
                    ''
                ])
        return logger


    finally:
        logging._releaseLock()


