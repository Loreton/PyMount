#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Version ......: 20-07-2020 14.47.49
#
# ref:
#   https://dev.to/taqkarim/extending-simplenamespace-for-nested-dictionaries-58e8
#

# --------------------
from types import SimpleNamespace
my_namespace = SimpleNamespace(a=1, b=2, c=3)

my_namespace.a # 1
my_namespace.b # 2
my_namespace.c # 3


# --------------------
from types import SimpleNamespace
my_dict = {
  "a": 1,
  "b": 2,
  "c": 3,
}
my_namespace = SimpleNamespace(**my_dict)
my_namespace.a # 1
my_namespace.b # 2
my_namespace.c # 3


# --------------------
class RecursiveNamespace: # without extending SimpleNamespace!
  @staticmethod
  def map_entry(entry):
    if isinstance(entry, dict):
      return RecursiveNamespace(**entry)

    return entry

  def __init__(self, **kwargs):
    for key, val in kwargs.items():
      if type(val) == dict:
        setattr(self, key, RecursiveNamespace(**val))
      elif type(val) == list:
        setattr(self, key, list(map(self.map_entry, val)))
      else: # this is the only addition
        setattr(self, key, val)

# this is how RecursiveNamespace looks when output
# RecursiveNamespace(**my_dict)