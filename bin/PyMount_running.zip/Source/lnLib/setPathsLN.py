#!/usr/bin/python
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 2021-05-03
#
import sys, os
from pathlib import Path

'''
# permette di fare l'import senza passare le subdirs
from    lnLib.setPathsLN import setPaths; setPaths(sub_dirs=[
                                                'Source',
                                                'Source/Security',
                                                'lnLib',
                                                ],
                                                fDEBUG=False)
'''



# permette di fare l'import senza passare le subdirs
def setPaths(sub_dirs=[], fDEBUG=False):
    # check if I'm inside a ZIP file or directory
    thisScript=Path(sys.argv[0]).resolve()
    script_path=thisScript.parent # ... then up one level

    my_path=[]
    if thisScript.suffix == '.zip': # potrei essere anche all'interno dello zip
        prj_main_dir=thisScript.parent.parent
        my_path.append(thisScript)
        script_path=thisScript # ... then up one level
    else:
        prj_main_dir=script_path

    my_path.append(prj_main_dir)
    for dir_name in sub_dirs:
        my_path.append(Path(script_path / dir_name))

    for item in my_path:
        sys.path.insert(0, str(item))
        if fDEBUG:
            print ('    ', item)


    return prj_main_dir