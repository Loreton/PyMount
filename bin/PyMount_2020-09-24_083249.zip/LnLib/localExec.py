#!/usr/local/bin/python3

# #############################################
#
# updated by ...: Loreto Notarantonio
# Version ......: 18-08-2020 08.23.43
#
# #############################################

import sys; sys.dont_write_bytecode=True
import subprocess, shlex


##################################################
# _alias_exec
##################################################
def runCommand(command, logger):
    splitted_cmd=shlex.split(command)
    logger.info('executing command:', "", command)

    try:
        p1=subprocess.run(splitted_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, check=True)
        logger.info('    rcode: ', p1.returncode)
        logger.debug1('    result:', p1.stdout)
        return p1.returncode, p1.stdout

    except subprocess.CalledProcessError as e:
        logger.error("ERROR:", "",
                          f"command:   {command}",
                          f"rcode:     {e.returncode}",
                          f"stdout:    {e.stdout.strip()}",
                          f"exception: {str(e)}")

        return e.returncode, e.stdout.strip()