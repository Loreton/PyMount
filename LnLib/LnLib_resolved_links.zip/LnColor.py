#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# updated by ...: Loreto Notarantonio
# Version ......: 20-07-2020 16.58.45
# Updates:
#   06-07-2020: messo il controllo sul text di tipo pathlib
# #########################################################
import sys, os


# from . import colorama_039 as colorama
from . import colorama_043 as colorama
import pathlib


class LnColor:
    colorama.init(wrap=True, convert=None, strip=None, autoreset=False)
    # for i in dir('LnColors'): print (i)
    '''
        devo mantenere i valori seguenti perché a volte
        devo mandare una stringa pronta con il colore e non posso usare il printColor(msg) oppure il getColor()
        in quanto ho una stringa multicolor
        usageMsg = " {COLOR}   {TEXT} {COLRESET}[options]".format(COLOR=C.YEL, TEXE='Loreto', COLRESET=C.RESET)

    '''
    FG         = colorama.Fore
    BG         = colorama.Back
    HI         = colorama.Style

    _black       = FG.BLACK
    _red         = FG.RED              ; _redH     = _red     + HI.BRIGHT
    _green       = colorama.Fore.GREEN ; _greenH   = _green   + HI.BRIGHT
    _yellow      = FG.YELLOW           ; _yellowH  = _yellow  + HI.BRIGHT
    _blue        = FG.BLUE             ; _blueH    = _blue    + HI.BRIGHT
    _magenta     = FG.MAGENTA          ; _magentaH = _magenta + HI.BRIGHT
    _cyan        = FG.CYAN             ; _cyanH    = _cyan    + HI.BRIGHT
    _white       = FG.WHITE            ; _whiteH   = _white   + HI.BRIGHT

    RESET        = HI.RESET_ALL
    BW           = FG.BLACK + BG.WHITE
    BWH          = FG.BLACK + BG.WHITE + HI.BRIGHT
    YellowOnBlask = FG.BLACK + BG.YELLOW

    _default = HI.RESET_ALL + FG.WHITE + BG.BLACK
    _reset = _default
    callerFunc = sys._getframe(1).f_code.co_name




    def __init__(self, filename=None):
        self._stdout = None
        self._stdout_colored = None
        self.colored_text = ''
        self.normal_text  = ''

        if filename:
            name,ext = filename.rsplit('.',1)
            colored_filename = name + '_colored.' + ext

            self._stdout = open(filename, "w", encoding='utf-8')
            self._stdout_colored = open(colored_filename, "w", encoding='utf-8')


    def setColor(self,  color=''):
        print (self._default + color, end='' )

    def getColored(self, text='', **args):
        self._prepareText (text=text, **args)
        return self.colored_text


    def toFile(self, end):
        if self._stdout:
            self._stdout.write('{0}{1}'.format(self.normal_text, end))
            self._stdout.flush()

        if self._stdout_colored:
            self._stdout_colored.write('{0}{1}'.format(self.colored_text, end))
            self._stdout_colored.flush()


    # - il return mi server per il get=True
    def resetColor(self, text='', **args):   return self.pprint(text, color=self._default, **args)
    def error(self, text='', **args):        return self.pprint(text, color=self._redH, **args)
    def warning(self, text='', **args):      return self.pprint(text, color=self._magentaH, **args)

    # - print colored
    def printWhite(self, text='', **args):        return self.pprint(text, color=self._white, **args)
    def printYellow(self, text='', **args):       return self.pprint(text, color=self._yellow, **args)
    def printCyan(self, text='', **args):         return self.pprint(text, color=self._cyan, **args)
    def printMagenta(self, text='', **args):      return self.pprint(text, color=self._magenta, **args)
    def printRed(self, text='', **args):          return self.pprint(text, color=self._red, **args)
    def printGreen(self, text='', **args):        return self.pprint(text, color=self._green, **args)
    def printBlue(self, text='', **args):         return self.pprint(text, color=self._blue, **args)

    def printWhiteH(self, text='', **args):       return self.pprint(text, color=self._whiteH, **args)
    def printYellowH(self, text='', **args):      return self.pprint(text, color=self._yellowH, **args)
    def printCyanH(self, text='', **args):        return self.pprint(text, color=self._cyanH, **args)
    def printMagentaH(self, text='', **args):     return self.pprint(text, color=self._magentaH, **args)
    def printRedH(self, text='', **args):         return self.pprint(text, color=self._redH, **args)
    def printGreenH(self, text='', **args):       return self.pprint(text, color=self._greenH, **args)
    def printBlueH(self, text='', **args):        return self.pprint(text, color=self._blueH, **args)

    # - back compatibility
    white=printWhite
    yellow=printYellow
    cyan=printCyan
    magenta=printMagenta
    red=printRed
    green=printGreen
    blue=printBlue
    whiteH=printWhiteH
    yellowH=printYellowH
    cyanH=printCyanH
    magentaH=printMagentaH
    redH=printRedH
    greenH=printGreenH
    blueH=printBlueH

    # - get colored
    def getWhite(self, text='', **args):        return self.getColored(text, color=self._white, **args)
    def getYellow(self, text='', **args):       return self.getColored(text, color=self._yellow, **args)
    def getCyan(self, text='', **args):         return self.getColored(text, color=self._cyan, **args)
    def getMagenta(self, text='', **args):      return self.getColored(text, color=self._magenta, **args)
    def getRed(self, text='', **args):          return self.getColored(text, color=self._red, **args)
    def getGreen(self, text='', **args):        return self.getColored(text, color=self._green, **args)
    def getBlue(self, text='', **args):         return self.getColored(text, color=self._blue, **args)

    def getWhiteH(self, text='', **args):       return self.getColored(text, color=self._whiteH, **args)
    def getYellowH(self, text='', **args):      return self.getColored(text, color=self._yellowH, **args)
    def getCyanH(self, text='', **args):        return self.getColored(text, color=self._cyanH, **args)
    def getMagentaH(self, text='', **args):     return self.getColored(text, color=self._magentaH, **args)
    def getRedH(self, text='', **args):         return self.getColored(text, color=self._redH, **args)
    def getGreenH(self, text='', **args):       return self.getColored(text, color=self._greenH, **args)
    def getBlueH(self, text='', **args):        return self.getColored(text, color=self._blueH, **args)



        # ----------------------------------------------
        # - print
        # ----------------------------------------------
    def pprint(self, end='\n', autoreset=True, toFile=False, get=False, **args):
        self._prepareText (**args)
        if get==True:
            return self.colored_text + self._default

        try:
            print (self.colored_text, end=end )

        except (UnicodeEncodeError):
            print ('{0} function: {1} - UnicodeEncodeError on next line {2}'.format(
                    LnColor.redH,
                    _function_name),
                end=end )
            print (self.normal_text.encode(string_encode, 'ignore'), end=end )


        if autoreset:
            print(self._default, end='')

        if toFile:
            self.toFile(end=end)

        self.colored_text = ''
        self.normal_text  = ''



    def _prepareText(self, color='', text='', tab=0, string_encode='latin-1'):
        if isinstance(text, (pathlib.PosixPath)):
            text=str(text)

        _function_name = sys._getframe().f_code.co_name
        thisTAB = ' '*tab
        # if not isinstance(text, str):
            # text = str(text)
        # ----------------------------------------------
        # - intercettazione del tipo text per fare un
        # - print più intelligente.
        # ----------------------------------------------

            # - convertiamo list in string (con il tab in ogni riga)
        if isinstance(text, (list, tuple)):
            myMsg = [text[0]]
            for line in text[1:]:
                myMsg.append('{0}{1}'.format(thisTAB, line.strip()))
            text = '\n'.join(myMsg)
            thisTAB = ''

        elif '\n' in text:
            '''
                cerchiamo la prima riga valida
                in essa contiamo i BLANK fino al primo char
                ci serve per eliminare tale spazio alle linee successive
                in modo da mantenere l'indentazione
            '''
            _text=text.split('\n')
            myMsg = []
            first_char=0
            for line in _text:
                if not myMsg: # cerchiamo prima entry valida
                    if line.strip():
                        first_char=len(line) - len(line.lstrip())
                        myMsg.append('{0}{1}'.format(thisTAB, line.strip()))
                else:
                    myMsg.append('{0}{1}'.format(thisTAB, line[first_char:]))

            text = '\n'.join(myMsg)
            thisTAB = ''

            # - convertiamo bytes in string
        if isinstance(text, bytes):
            text = text.decode('utf-8')


        self.colored_text = '{0}{1}{2}'.format(thisTAB, color, text)
        self.normal_text  = '{0}{1}'.format(thisTAB, text)
