#!/usr/bin/python
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Date .........: 2021-05-16

import sys, os
import json, yaml


# def dict_to_yaml_(d, title=None, fPrint=False, to_file=None, indent=4, sort_keys=False, logger=None, skip_no_serialization=True):
#     def is_jsonable(x):
#         try:
#             json.dumps(x)
#             return True
#         except (Exception) as e:
#             return str(e)


#     _d={} # per evitare di modificare l'originale...  #  by Loreto:  01-04-2021 14.21.53
#     for key, value in d.items():
#         response=is_jsonable(value)
#         if response is True:
#             _d[key]=value
#         else:
#             if skip_no_serialization:
#                 pass
#             else:
#                 _d[key]=f"removed due to: {response}"

#     if title:
#         _d={title: _d}

#     json_data=json.dumps(_d, indent=indent, sort_keys=sort_keys)

#     yaml_data = yaml.dump(yaml.load(json_data, Loader=yaml.FullLoader), indent=indent, sort_keys=sort_keys, default_flow_style=False)
#     if to_file:
#         os.makedirs(os.path.dirname(to_file),  exist_ok=True)
#         with open(to_file, "w") as f:
#             f.write('{0}\n'.format(yaml_data))
#         if logger: logger.debug("file", to_file, "has been created")
#     elif fPrint:
#         print(yaml_data)
#     return yaml_data



def dict_to_yaml(d, title=None, indent=4, sort_keys=False):
    assert isinstance(d, dict)==True
    def is_jsonable(x):
        try:
            json.dumps(x)
            return x
        except (Exception) as e:
            return str(e)

    _d={} # per evitare di modificare l'originale...  #  by Loreto:  01-04-2021 14.21.53
    for key, value in d.items():
        _d[key]=is_jsonable(value)

    if title:
        _d={title: _d}

    json_data=json.dumps(_d, indent=indent, sort_keys=sort_keys)
    yaml_data=yaml.dump(yaml.load(json_data, Loader=yaml.FullLoader), indent=indent, sort_keys=sort_keys, default_flow_style=False)

    return yaml_data


def string_to_yaml(my_str="{1: 2}"):
    yaml.safe_load("{1: 2}", Loader=yaml.SafeLoader)


def print_dict(d):
    print(dict_to_yaml(d))


def writeYamlFile(*, d, file_out, title=None, indent=4, sort_keys=False, logger=None):
    if logger:
        logger.info('Entering...')
        logger.info(f'Writing file: {file_out}')
    yaml_data=dict_to_yaml(d, title=title, indent=indent, sort_keys=sort_keys)
    os.makedirs(os.path.dirname(file_out),  exist_ok=True)
    with open(file_out, "w") as f:
        f.write(f'{yaml_data}\n')



# def writeYamlFile(file_out, data):
#     json_data = data
#     if isinstance(data, dict):
#         json_data = json.dumps(data, indent=4, sort_keys=True)

#     yaml_data = yaml.dump(yaml.load(json_data, Loader=yaml.FullLoader), indent=4, sort_keys=True, default_flow_style=False)
#     with open(file_out, "w") as f:
#         f.write('{0}\n'.format(yaml_data))


def readYamlFile(filename, logger=None):
    if logger:
        logger.info('Entering...')
        logger.info(f'Reading file: {filename}')
    with open(filename, 'r') as fin:
        return(yaml.load(fin, Loader=yaml.FullLoader))