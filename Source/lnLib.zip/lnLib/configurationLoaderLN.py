#!/usr/bin/python

# #############################################
#
# updated by ...: Loreto Notarantonio
# Date .........: 2021-05-05
#
# #############################################

import  sys; sys.dont_write_bytecode=True
import  os
# from    benedict import benedict
from    pathlib import Path
import  zipfile
import  io
import  yaml, pyaml

this=sys.modules[__name__]
myCls=None




##############################################################
# Constructors
##############################################################


# https://gist.github.com/joshbode/569627ced3076931b02f
from typing import Any, IO


class Loader(yaml.SafeLoader):
    env_tag = u'!env'
    include_tag = u'!include'

    def __init__(self, stream: IO) -> None:
        """Initialise Loader."""

        ''' non sembra mi siano utili
        try:
            self._root = os.path.split(stream.name)[0]
        except AttributeError:
            self._root = os.path.curdir
        '''
        super().__init__(stream)


############################################
#
############################################
class ConfigurationLoader(object):
    def __init__(self, filename, paths=['conf', 'conf/templates']):
        global myCls

        self.paths=[''] # per curr folder
        self.paths.extend(paths)
        script_path=Path(sys.argv[0]).resolve()
        if not script_path.parent in self.paths:
            self.paths.append(script_path.parent)

        self.files={} # salviamo i file letti per non rileggerli....

        if zipfile.is_zipfile(script_path):
            self.isZip=True
            self.zipFile=script_path
            z=zipfile.ZipFile(self.zipFile, "r")
            self.zipNamelist=z.namelist()
            # print(self.zipNamelist)
        else:
            self.isZip=False


        self.filename=Path(filename)
        myCls=self




    ############################################
    #
    ############################################
    def read(self):
        content=self.read_file(self.filename)

        data=yaml.load(content, Loader) # qui scattano i costruttori

        # risultato finale
        extension=self.filename.suffix
        if extension=='.yaml':
            # content = yaml.load(content, Loader=yaml.FullLoader)
            content = yaml.load(content, Loader=Loader)

            # content = yaml.dump(data, default_flow_style=False)
        return content


    ############################################
    #
    ############################################
    def read_file(self, filename):
        file=self.getFilePath(filename)
        if file in self.files:
            return self.files[file]

        if self.isZip:
            content=self.read_file_in_zip(filename=file)
        else:
            with open(file, 'r') as f:
                content=f.read() # single string

        self.files[file]=content # salviamo i file letti
        return content


    ############################################
    #
    ############################################
    def read_file_in_zip(self, filename):
        content=[]
        z=zipfile.ZipFile(self.zipFile, "r")
        with z.open(str(filename)) as f:
            _data=f.read()
        _buffer=io.TextIOWrapper(io.BytesIO(_data))
        # contents =io.TextIOWrapper(io.BytesIO(_data), encoding='iso-8859-1', newline='\n')#
        for line in _buffer:
            content.append(line)
        # content='\n'.join(content)
        content=''.join(content)

        return content


    ############################################
    #
    ############################################
    def getFilePath(self, fname):
        file=None
        for path in self.paths:
            f=os.path.join(path, fname)
            if self.isZip and f in self.zipNamelist:
                file=f
                break
            else:
                if os.path.exists(f):
                    file=f
                    break

        if not file:
            print('     file', fname, ' not found')
            import inspect
            caller=inspect.stack()[0]
            fname=caller.filename.rsplit('.', 1)[0]
            funcname=os.sep.join(fname.split(os.sep)[-2:])
            msg=f"{funcname}:{caller.lineno}"
            print('     on function:', msg)

            if self.isZip:
                for _dir in self.zipNamelist:
                    print( _dir)
            sys.exit()

        return file




############################################
#
############################################
def construct_include(loader: Loader, node: yaml.Node) -> Any:
    """Include file referenced at node."""
    fDEBUG=False
    fname, *key_ptr=loader.construct_scalar(node).split('#')

    if fDEBUG:
        print('current node  :', loader.construct_scalar(node))
        print('filename path :', fname)

    #---- read config file
    content=myCls.read_file(fname)

    extension=os.path.splitext(fname)[1].lstrip('.')
    if extension in ('yaml', 'yml'):
        content=yaml.load(content, Loader)

    elif extension in ('json', ):
        content=json.load(content)

    # get required key_path....
    if key_ptr:
        if fDEBUG:
            print('     key  :', key_ptr)
        if len(key_ptr)>1 and key_ptr[1]=='only_keys':
            onlyKeys=True # return just a list of keys
        else:
            onlyKeys=False

        try:
            key_path=key_ptr[0].split('.')
            for key in key_path:
                content=content[key] # con errore in caso not found
        except (Exception) as e:
            exit(str(e))

        if onlyKeys:
            content=list(content.keys())

    return content


############################################
#
############################################
def construct_env(loader: Loader, node: yaml.Node) -> Any:
    var_name=loader.construct_scalar(node)
    return os.environ.get(var_name, '')


yaml.add_constructor('!include', construct_include, Loader)
yaml.add_constructor("!env", construct_env, Loader)

''' da inserire https://stackoverflow.com/questions/2063616/how-to-reference-a-yaml-setting-from-elsewhere-in-the-same-yaml-file
## define custom tag handler
def join(loader, node):
    seq = loader.construct_sequence(node)
    return ''.join([str(i) for i in seq])

## register the tag handler
yaml.add_constructor('!join', join)

## using your sample data
yaml.load("""
paths:
    root: &BASE /path/to/root/
    patha: !join [*BASE, a]
    pathb: !join [*BASE, b]
    pathc: !join [*BASE, c]
""")
'''



def exit(err_msg):
    print()
    print(err_msg)
    print()
    print('parent filename :')
    for name in Loader.files.keys():
        print('     ', name)
    print('current node    :', loader.construct_scalar(node))
    print()
    sys.exit(2)




def Main(filename):
    myClass=ConfigurationLoader(filename)
    content=myClass.read()
    return content

if __name__ == '__main__':
    os.environ['Yaml_VAR']="Ciao Loreto"
    filename='main_config.yaml'
    myClass=ConfigurationLoader(filename)
    construct_env.myCls=myClass
    construct_include.myCls=myClass
    content=myClass.read()
    print(yaml.dump(content, default_flow_style=False))
