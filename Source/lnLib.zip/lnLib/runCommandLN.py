#!/usr/bin/python
# #############################################
#
# updated by ...: Loreto Notarantonio
# Version ......: 24-10-2020 18.54.09
#
# #############################################

import sys; sys.dont_write_bytecode=True
import subprocess, shlex
from subprocess import Popen, PIPE, STDOUT

##################################################
# - alternativa _alias_exec
# - return rcode, output
##################################################
def runCommand(command, my_logger,
                        grep_data=[],
                        exit_on_error=False,
                        split_lines=False,
                        remove_empty_lines=False,
                        fEXECUTE=True,
                        # rcode_not_zero=False
                        ):
    global logger
    logger=my_logger

    logger.info('executing command:', "",  command)


    rcode, output = localExec(command, fEXECUTE=fEXECUTE)

    #- strip right output
    output=output.rstrip().rstrip('\n').rstrip()

    if rcode and exit_on_error:
        logger.critical('exiting on exit_on_error flag')


    if split_lines and '\n' in output:
        output=output.splitlines()
        if remove_empty_lines:
            output=[x.strip() for x in output if x]


    # - save all matching lines
    if grep_data:
        lines=[]
        for line in output:
            matches=[x for x in grep_data if x in line]
            if len(matches)==len(grep_data):
                lines.append(line)
        output=lines

    return rcode, output

run_command=runCommand

########################################
# Es. il comando diff
#        Exit status is 0 if inputs are the same, 1 if different, 2 if trouble.
########################################
def run_rcode_not_0(command, fEXECUTE=False):
    splitted_cmd=shlex.split(command)
    p1 = subprocess.Popen(splitted_cmd, stdout=PIPE, stderr=STDOUT, universal_newlines=True)
    output, error = p1.communicate()
    return p1.returncode, output, error




##################################################
#
##################################################
def localExec(command, fEXECUTE=False):
    if not fEXECUTE:
        command='ls -la'

    splitted_cmd=shlex.split(command)

    try:
        p1 = subprocess.run(splitted_cmd,   # waits for it to finish
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        universal_newlines=True,
                        check=True)

        rcode=p1.returncode

        output=p1.stdout if hasattr(p1, 'stdout') else p1.output
        _stderr=p1.stderr

    except (Exception) as e:
        rcode=1
        output=None
        _stderr=str(e)
        logger.error("command:", command, "rcode:", rcode, "exception:", _stderr)
        print("command:", command, "rcode:", rcode, "exception:", _stderr)

    return rcode, output

