#!/usr/bin/python2.7
# -*- coding: utf-8 -*-

# updated by ...: Loreto Notarantonio
# Version ......: 13-05-2020 12.47.55
#
# 05-11-2018: creato _printLog unico sia per console che per log
#
import sys, os, time
import json, yaml
if sys.version_info >= (3,0):
    unicode = str

###########################################
# - converte LnClass o LnDict in dict
###########################################
def toDict(data):
    # print (type(data))
    _myDict = {}
    dataType = str(type(data)).lower()

    if 'dotmap' in dataType:
        print ('dotamp')
        _myDict = data.toDict()


    elif 'lnclass' in dataType:
        print ('lnclass')
        for item in vars(data):
            _myDict[item] = getattr(data, item)

    else:
        _myDict = data

    return _myDict



##############################################################################
# - classe che mi permette di lavorare nel caso il logger non sia richiesto
##############################################################################
class nullLogger():
    def __init__(self, log_modules=[]):
        self._log_modules = log_modules
        pass

    def dummy(self,  title, *args, **kwargs):
        if 'console' in kwargs and kwargs['console']==True:
            self.console(title, *args, stacknum=3)

    def critical(self,  title, *args, **kwargs):
        self.console(title, *args, stacknum=3)
        self.console('Exiting from program', stacknum=3)
        sys.exit(1)


    def console(self,  title, *args, **kwargs):
        if isinstance(title, (float, int)):
            title = '{title}'.format(**locals())
        no_title = ' '*len(title)

        if 'stacknum' in kwargs:
            stacknum=kwargs['stacknum']
        else:
            stacknum=2

        caller = _getCaller(stackNum=stacknum, modules=self._log_modules)
        if not caller:
            return

        console_prefix = "{} -> ".format(caller)
        if not args: args=(' ')# per processare quando esiste solo il titolo


        for index, item in enumerate(args):
            if index > 0: title=no_title
            data = prepareData(title, item)
            for line in data:
                print(console_prefix + line)


    info    = dummy
    debug   = dummy
    debug1  = dummy
    debug2  = dummy
    debug3  = dummy
    error   = dummy
    critical= console # comunque send message

class myLogger():
    def __init__(self, filename, console=False, debug_level=-1, log_modules=[], color=None):
        global C
        self._debugLevel        = debug_level
        self._date_time_format  = '%m-%d %H:%M:%S'
        self._log_modules = log_modules
        self._console = console
        C = color

        # if filename:
        self.logger = open(filename,'w', encoding='utf-8')
            # Messaggio iniziale nel LOG
        self._printLog('INFO', '\n'*5,
                [
                    '-'*50,
                    '- starting:    ' + time.strftime("%Y/%m/%d %H:%M:%S"),
                    '- debug level: ' + str(debug_level),
                    '- log_modules: ' + str(self._log_modules),
                    '- log_console: ' + str(self._console),
                    '-'*50,
                    ''
                ])

    def isLoggedModule(self, data):
        FOUND = False
        if self._log_modules in ([], ['*'], ['all']):
            FOUND = True
        else:
            for module in self._log_modules:
                if module.lower() in data.lower():
                    FOUND = True
                    break

        return FOUND

    def _printLog_New(self, level=None, title=None, *args, **kwargs):
        assert isinstance(title, (str, unicode))
        if isinstance(title, (float, int)):
            title = '{title}'.format(**locals())
        no_title = ' '*len(title)

        if 'console' in kwargs and kwargs['console']==True:
            to_console = True
        else:
            to_console = False


        caller = _getCaller(stackNum=3, modules=self._log_modules)

        if level in ['CRITICAL']: # prosegui senza guardare il module filter
            pass
        elif not self.isLoggedModule(caller):
            return

        now = time.strftime("%Y/%m/%d %H:%M:%S")
        disp_level = level[:5]

        log_prefix = "{} - {} {} -> ".format(now, caller, disp_level)
        console_prefix = "{} -> ".format(caller)


        if not args: args=(' ')# per processare quando esiste solo il titolo
        for index, item in enumerate(args):
            if index > 0: title=no_title
            data = prepareData(title, item)

            # data = prepareData(title, args)
            for line in data:
                if level in ['CONSOLE', 'CRITICAL'] or self._console or to_console:
                    if C:
                        C.yellow(text=console_prefix, end='')
                        C.yellowH(text=line)
                    else:
                        print(console_prefix + line)

                self.logger.write(log_prefix + line + '\n')

        self.logger.flush()  #  by Loreto:  01-11-2018 18.55.13



    def _printLog(self, level=None, title=None, *args):
        if isinstance(title, (float, int)):
            title = '{title}'.format(**locals())
        no_title = ' '*len(title)

        caller = _getCaller(stackNum=3, modules=self._log_modules)

        if not self.isLoggedModule(caller):
            return

        now = time.strftime("%Y/%m/%d %H:%M:%S")
        disp_level = level[:5]

        log_prefix = "{} - {} {} -> ".format(now, caller, disp_level)
        console_prefix = "{} -> ".format(caller)


        if not args: args=(' ')# per processare quando esiste solo il titolo
        for index, item in enumerate(args):
            if index > 0: title=no_title
            data = prepareData(title, item)

            # data = prepareData(title, args)
            for line in data:
                if level in ['CONSOLE', 'CRITICAL'] or self._console:
                    if C:
                        C.yellow(text=console_prefix, end='')
                        C.yellowH(text=line)
                    else:
                        print(console_prefix + line)

                self.logger.write(log_prefix + line + '\n')

        self.logger.flush()  #  by Loreto:  01-11-2018 18.55.13



        # args può essere tuple, list, str o altro da verificare

    def info(self,  title, *args, **kwargs):
        self._printLog_New('INFO', title, *args, **kwargs)

    # def info_(self,  title, *args, **kwargs):
    #     assert isinstance(title, (str, unicode))
    #     if 'console' in kwargs and kwargs['console']==True:
    #         self._console = True
    #         self._printLog('INFO', title, *args)
    #         self._console = False

    def debug(self,  title, *args, **kwargs):
        # assert isinstance(title, (str, unicode))
        if self._debugLevel >= 0:
            self._printLog_New('DBG', title, *args, **kwargs)

    def debug1(self,  title, *args, **kwargs):
        # assert isinstance(title, (str, unicode))
        if self._debugLevel >= 1:
            self._printLog_New('DBG1', title, *args, **kwargs)

    def debug2(self,  title, *args, **kwargs):
        # assert isinstance(title, (str, unicode))
        if self._debugLevel >= 2:
            self._printLog_New('DBG2', title, *args, **kwargs)

    def debug3(self,  title, *args, **kwargs):
        # assert isinstance(title, (str, unicode))
        if self._debugLevel >= 3:
            self._printLog_New('DBG3', title, *args, **kwargs)

    def error(self,  title, *args, **kwargs):
        # if 'console' in kwargs and kwargs['console']==True:
            # self._console = True
        self._printLog_New('ERROR', title, *args, **kwargs)
            # self._console = False

    def critical(self,  title, *args, **kwargs):
        self._console = True
        self._printLog_New('CRITICAL', title, *args, **kwargs)
        self._printLog_New('CRITICAL', 'Exiting from program')
        self.logger.flush()   #  by Loreto:  08-04-2020 09.28.55
        sys.exit(1)

    def console(self, title, *args, **kwargs):
        self._printLog_New('CONSOLE', title, *args, **kwargs)

    def _dummy(self, level=None, title=None, *args):
        pass



def _getCaller(stackNum=3, modules=[]):
    caller = sys._getframe(stackNum)
    programFile = caller.f_code.co_filename
    lineNumber  = caller.f_lineno
    funcName    = caller.f_code.co_name

    if funcName == '<module>': funcName = '__main__'
    fname = os.path.basename(programFile).split('.')[0]
    pkg = funcName
    pkg = fname + '.' + funcName
    pkg = pkg.replace('ansible_module_', '')


    _caller = "[{FUNC:<15}:{LINENO:4}]".format(FUNC=pkg, LINENO=lineNumber)
    return _caller


def prepareData(title, args):
    data_list = []
    TAB=4*' '

    if isinstance(args, (list, tuple)):
        data_list.append(title + ' [list={}]:'.format(len(args)))
        if len(args):
            for index, item in enumerate(args):
                data = '{}[{:04}] - {}'.format(TAB, index, item)
                data_list.append(data)
        else:
            data = '{}- []'.format(TAB)
            data_list.append(data)

    elif isinstance(args, dict): # anche DotMap?
        data_list.append(title + '[dict]:')
        my_json = json.dumps(args, indent=4, sort_keys=True)
        my_yaml = yaml.dump(yaml.load(my_json), default_flow_style=False)
        for line in my_json.split('\n'):
            data_list.append(line)

    elif isinstance(args, (bool, int, float)):
        # data = '{}: {}'.format( title, str(args))
        data = '{title} {args}'.format(**locals())
        data_list.append(data)

    elif args in ['']:
        data_list.append(title)

    elif not args.strip():
        data_list.append(title)

    else:
        data = '{title} {args}'.format(**locals())
        data_list.append(data)

    return data_list



def setLogger(filename=None, console=False, debug_level=0, log_modules=[], color=None):
    if filename:
        return myLogger(filename, console, debug_level, log_modules, color)
    else:
        return nullLogger(log_modules)

