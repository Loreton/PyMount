#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Version ......: 30-05-2020 15.06.17
#
# Scope:  aggiunge dei metodi alle classi di sistema
#
# ######################################################################################
import sys
import shutil

from pathlib import Path
from time import strftime

################################################
################################################
def LnMonkeySet(lnLogger):
    global logger
    logger = lnLogger

################################################
################################################
def LnPathCopy(source, target, logger):
    #assert Path(source).is_file()
    '''
    alternative of Path.copy
    copyfile only if size or mtime ad differents
    params:
        target : target
        vSize  : verify fileSize
        vMTime : verify mTime
    '''

    source = Path(source)
    target = Path(target)
    logger.info('working on files: {} - {}'.format(source._str, target._str))
    diffSize, diffTime = False, False
    src = source.stat()
    tgt = src # default nel caso target non esista.
    if target.exists():
        tgt = target.stat()
        diffSize = (src.st_size != tgt.st_size)
        diffTime = (src.st_mtime > tgt.st_mtime)

    logger.info('diffTime value: {0} <--> {1}'.format(src.st_mtime, tgt.st_mtime))
    logger.info('diffSize value: {0} <--> {1}'.format(src.st_size, tgt.st_size))

    if diffTime:
        logger.info('copying file...')
        shutil.copy(source._str, target._str)
    elif diffSize:
        logger.warning('same DATETIME but different SIZE... NOT copied')
    else:
        logger.info('DATETIME and SIZE are equals. copy skipped...')


################################################
#  by Loreto:  16-04-2020 07.29.01
################################################
def LnPathMoveFile(source, target, create_parent=True, replace=False):
    assert source.is_file()
    source = Path(source)
    target = Path(target)
    logger.info('''moving file:
                        from {source}
                        to   {target}'''.format(**locals()))

    # create tree if required and not exists
    if create_parent:
        target.parent.mkdir(parents=True, exist_ok=True)

    moved = False
    reason = '___'
    if target.exists():
        if target.is_file():
            logger.info('File already exists on destination path.')
            if replace:
                logger.info('Moving and Replacing...')
                dest = shutil.move(str(source), str(target))
                if dest==str(target):
                    moved = True
                    reason = 'replaced'
            else:
                logger.info('Skipping...')
                reason = 'existing'
        else:
            logger.abend("Target exists but it's not a file... Exiting.")
            reason = "target_is_not_file"

    else:
        logger.info('moving file...')
        dest=shutil.move(str(source), str(target))
        if dest==str(target):
            moved = True
            reason = "moved"

    return moved, reason

######################################################
#
######################################################
def LnPathBackup(source, targetDir=None, logger=None):
    assert source.is_file()

    if not targetDir: targetDir = source.parent
    fname = '{NAME}_{DATE}{EXT}'.format(NAME=str(source.parent.name), DATE=strftime('%Y-%m-%d_%H_%M'), EXT=str(source.suffix))
    backupFile = Path(targetDir).joinpath(fname)
    backupFile = Path(backupFile)
    shutil.copy(str(source), str(backupFile))

######################################################
#
######################################################
def LnPath2String(source):
    return str(source)



######################################################
#
######################################################
'''
def checkPath(_path, errorOnPathNotFound=True):
    if isinstance(_path, WindowsPath):
        _path = str(_path.resolve())
    elif isinstance(_path, str):
        _path = str(Path(_path).resolve())

    if _path[1] == ':':
        _path = Path(_path).resolve() # absolute path and cut  \\\\ excedents
        if not _path.exists():
            if errorOnPathNotFound:
                print('\n    {_path} path NOT FOUND. Pls change the config file.\n'.format(**locals()))
                sys.exit(1)
            else:
                choice=keyb_input('\n   {_path} file NOT FOUND. [I]gnore'.format(**locals()), validKeys='i|I')
    return str(_path)
'''


# inseriamo i miei comandi nella classe Path.
Path.copyTo   = LnPathCopy
Path.backup = LnPathBackup
Path.moveTo = LnPathMoveFile
Path.LnSet = LnMonkeySet
Path.toStr = LnPath2String
# Path.LnVerify = checkPath